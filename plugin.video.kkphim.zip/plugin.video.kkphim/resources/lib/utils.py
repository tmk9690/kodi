import os
import re
import json
import requests
from codequick import Script
from xbmcvfs import translatePath


# ============================================================
# CẤU HÌNH
# ============================================================

USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
BASE_API = 'https://phimapi.com'
BASE_WEB = 'https://kkphim.com'
ADDON_DATA = os.path.join(
    translatePath('special://userdata/addon_data'),
    'plugin.video.kkphim'
)


# ============================================================
# HTTP
# ============================================================

def get_json(url, params=None, timeout=30):
    headers = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    try:
        r = requests.get(url, headers=headers, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi gọi API {url}: {e}')
        return None


# ============================================================
# STREAM
# ============================================================

def stream(url):
    if not url:
        return url
    return f'{url}|User-Agent={USER_AGENT}'


def fix_image(url):
    if isinstance(url, str) and url.startswith('http'):
        return url
    return 'https://raw.githubusercontent.com/kenvnm/kvn/main/kkphim.png'


# ============================================================
# LƯU TRỮ FILE
# ============================================================

def _ensure_dir():
    if not os.path.exists(ADDON_DATA):
        os.makedirs(ADDON_DATA)


def _file_path(name):
    _ensure_dir()
    return os.path.join(ADDON_DATA, name)


def read_json_file(name, default=None):
    path = _file_path(name)
    if not os.path.exists(path):
        return default if default is not None else []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi đọc file {name}: {e}')
        return default if default is not None else []


def write_json_file(name, data):
    path = _file_path(name)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi ghi file {name}: {e}')
        return False


# ============================================================
# RESUME POSITION (theo từng server)
# ============================================================

RESUME_FILE = 'resume_positions.json'
MAX_RESUME = 50


def save_resume_position(movie_slug, episode_name, position_seconds,
                         total_seconds, server_name=''):
    """Lưu vị trí xem dở. Key = slug|server|episode."""
    import time
    if not movie_slug or not episode_name:
        return

    key = f'{movie_slug}|{server_name}|{episode_name}'
    data = read_json_file(RESUME_FILE, {})

    # Xem gần hết (>95%) → xóa
    if total_seconds > 0 and position_seconds / total_seconds > 0.95:
        if key in data:
            del data[key]
            write_json_file(RESUME_FILE, data)
        return

    # Xem chưa đủ 30 giây → không lưu
    if position_seconds < 30:
        return

    data[key] = {
        'pos': int(position_seconds),
        'total': int(total_seconds),
        'time': int(time.time()),
    }

    if len(data) > MAX_RESUME:
        sorted_items = sorted(
            data.items(),
            key=lambda x: x[1].get('time', 0),
            reverse=True
        )
        data = dict(sorted_items[:MAX_RESUME])

    write_json_file(RESUME_FILE, data)


def get_resume_position(movie_slug, episode_name, server_name=''):
    """Trả về (pos, total) hoặc (0, 0)."""
    if not movie_slug or not episode_name:
        return (0, 0)
    key = f'{movie_slug}|{server_name}|{episode_name}'
    data = read_json_file(RESUME_FILE, {})
    entry = data.get(key, {})
    return (entry.get('pos', 0), entry.get('total', 0))


def clear_resume_position(movie_slug, episode_name, server_name=''):
    if not movie_slug or not episode_name:
        return
    key = f'{movie_slug}|{server_name}|{episode_name}'
    data = read_json_file(RESUME_FILE, {})
    if key in data:
        del data[key]
        write_json_file(RESUME_FILE, data)


# ============================================================
# TỰ ĐỘNG CẤU HÌNH CACHE KODI
# ============================================================

CACHE_SIZE_MB = 200
READ_FACTOR = 20
BUFFER_MODE = 1


def setup_kodi_cache():
    try:
        userdata_dir = translatePath('special://userdata')
        if not userdata_dir or not os.path.exists(userdata_dir):
            return False

        advancedsettings_path = os.path.join(userdata_dir, 'advancedsettings.xml')
        cache_bytes = CACHE_SIZE_MB * 1024 * 1024

        new_content = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<advancedsettings>\n'
            '    <cache>\n'
            f'        <buffermode>{BUFFER_MODE}</buffermode>\n'
            f'        <memorysize>{cache_bytes}</memorysize>\n'
            f'        <readfactor>{READ_FACTOR}</readfactor>\n'
            '    </cache>\n'
            '    <network>\n'
            '        <curlclienttimeout>30</curlclienttimeout>\n'
            '        <curllowspeedtime>30</curllowspeedtime>\n'
            '    </network>\n'
            '</advancedsettings>\n'
        )

        old_content = None
        if os.path.exists(advancedsettings_path):
            try:
                with open(advancedsettings_path, 'r', encoding='utf-8') as f:
                    old_content = f.read()
            except Exception as e:
                Script.log(f'[KKPhim] Lỗi đọc file cũ: {e}')

        if old_content == new_content:
            return True

        if old_content and '<memorysize>' in old_content:
            match = re.search(r'<memorysize>(\d+)</memorysize>', old_content)
            if match:
                old_size = int(match.group(1))
                if old_size >= cache_bytes:
                    return True

        try:
            with open(advancedsettings_path, 'w', encoding='utf-8') as f:
                f.write(new_content)
            Script.log(f'[KKPhim] Đã tạo advancedsettings.xml với cache {CACHE_SIZE_MB}MB')
            return True
        except Exception as e:
            Script.log(f'[KKPhim] Lỗi ghi file advancedsettings.xml: {e}')
            return False

    except Exception as e:
        Script.log(f'[KKPhim] Lỗi setup cache: {e}')
        return False