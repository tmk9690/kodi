import re
from codequick import Route, Listitem, Resolver, Script
from resources.lib.utils import (
    get_json, stream, fix_image,
    read_json_file, write_json_file,
    save_resume_position, get_resume_position, clear_resume_position,
    BASE_API, BASE_WEB, USER_AGENT,
)
from concurrent.futures import ThreadPoolExecutor
from html import unescape
from xbmc import Keyboard, executebuiltin, Player, Monitor

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)


# ============================================================
# DIALOG TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem_dialog(plugin):
    keyboard = Keyboard('Tìm kiếm phim', default='')
    keyboard.doModal()

    if keyboard.isConfirmed():
        search_query = keyboard.getText().strip()
        if search_query:
            yield from tim_kiem(plugin, search_query)
        else:
            yield Listitem()
    else:
        yield Listitem()


# ============================================================
# HÀM LẤY THÔNG TIN TÓM TẮT PHIM
# ============================================================

def get_movie_info(slug):
    data = get_json(f'{BASE_API}/phim/{slug}')
    if not data:
        return None
    try:
        movie = data.get('movie', data)
        name = movie.get('name', 'Không có tên')
        poster = fix_image(movie.get('poster_url') or movie.get('thumb_url'))
        content = unescape(movie.get('content', '') or '')
        content = re.sub(r'<[^>]+>', '', content)
        year = movie.get('year', '')
        return (name, poster, content, year)
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi parse info {slug}: {e}')
        return None


def process_url(slug):
    return slug, get_movie_info(slug)


# ============================================================
# DANH SÁCH PHIM
# ============================================================

@Route.register
def danh_sach(plugin, slug='phim-moi-cap-nhat', page=1):
    if slug == 'phim-moi-cap-nhat':
        url = f'{BASE_API}/danh-sach/phim-moi-cap-nhat-v2'
    else:
        url = f'{BASE_API}/v1/api/danh-sach/{slug}'

    data = get_json(url, {'page': page, 'limit': 30})
    if not data:
        yield Listitem()
        return

    items = []
    if isinstance(data, dict):
        if 'data' in data and isinstance(data['data'], dict):
            items = data['data'].get('items', [])
        else:
            items = data.get('items', [])

    if not items:
        item = Listitem()
        item.label = 'Không có phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    slugs = [item.get('slug') for item in items if item.get('slug')]
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(process_url, slugs)
        for s, info in results:
            if info:
                name, poster, content, year = info
                list_item = Listitem()
                list_item.label = f'{name} ({year})' if year else name
                list_item.info['plot'] = content or f'Phim: {name}'
                list_item.info['mediatype'] = 'tvshow'
                list_item.info['year'] = year
                list_item.art['thumb'] = list_item.art['poster'] = poster
                list_item.set_callback(chi_tiet, s)
                yield list_item

    if len(items) >= 30:
        next_item = Listitem()
        next_item.label = f'Trang {page + 1}'
        next_item.art['thumb'] = TRANSPARENT_ICON
        next_item.set_callback(danh_sach, slug, page + 1)
        yield next_item


# ============================================================
# THỂ LOẠI
# ============================================================

@Route.register
def the_loai(plugin):
    data = get_json(f'{BASE_API}/the-loai')
    if not data:
        yield Listitem()
        return

    items = []
    if isinstance(data, dict):
        items = data.get('data', {}).get('items', [])
    elif isinstance(data, list):
        items = data

    if not items:
        item = Listitem()
        item.label = 'Không tải được thể loại'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    for item_data in items:
        name = item_data.get('name', '')
        slug = item_data.get('slug', '')
        if not slug:
            continue

        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach_the_loai, slug, 1)
        yield item


@Route.register
def danh_sach_the_loai(plugin, slug, page=1):
    url = f'{BASE_API}/v1/api/the-loai/{slug}'
    yield from _hien_thi_danh_sach(plugin, url, page, 'the-loai', slug)


# ============================================================
# QUỐC GIA
# ============================================================

@Route.register
def quoc_gia(plugin):
    data = get_json(f'{BASE_API}/quoc-gia')
    if not data:
        yield Listitem()
        return

    items = []
    if isinstance(data, dict):
        items = data.get('data', {}).get('items', [])
    elif isinstance(data, list):
        items = data

    if not items:
        item = Listitem()
        item.label = 'Không tải được quốc gia'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    for item_data in items:
        name = item_data.get('name', '')
        slug = item_data.get('slug', '')
        if not slug:
            continue

        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach_quoc_gia, slug, 1)
        yield item


@Route.register
def danh_sach_quoc_gia(plugin, slug, page=1):
    url = f'{BASE_API}/v1/api/quoc-gia/{slug}'
    yield from _hien_thi_danh_sach(plugin, url, page, 'quoc-gia', slug)


# ============================================================
# HÀM DÙNG CHUNG HIỂN THỊ DANH SÁCH
# ============================================================

def _hien_thi_danh_sach(plugin, api_url, page, loai, slug):
    data = get_json(api_url, {'page': page, 'limit': 30})
    if not data:
        yield Listitem()
        return

    items = []
    if isinstance(data, dict):
        if 'data' in data and isinstance(data['data'], dict):
            items = data['data'].get('items', [])
        else:
            items = data.get('items', [])

    if not items:
        item = Listitem()
        item.label = 'Không có phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    slugs = [item.get('slug') for item in items if item.get('slug')]
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(process_url, slugs)
        for s, info in results:
            if info:
                name, poster, content, year = info
                list_item = Listitem()
                list_item.label = f'{name} ({year})' if year else name
                list_item.info['plot'] = content or f'Phim: {name}'
                list_item.info['mediatype'] = 'tvshow'
                list_item.info['year'] = year
                list_item.art['thumb'] = list_item.art['poster'] = poster
                list_item.set_callback(chi_tiet, s)
                yield list_item

    if len(items) >= 30:
        next_item = Listitem()
        next_item.label = f'Trang {page + 1}'
        next_item.art['thumb'] = TRANSPARENT_ICON
        if loai == 'the-loai':
            next_item.set_callback(danh_sach_the_loai, slug, page + 1)
        else:
            next_item.set_callback(danh_sach_quoc_gia, slug, page + 1)
        yield next_item


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem(plugin, search_query):
    if not search_query:
        return

    save_search_history(search_query)

    from urllib.parse import quote_plus
    keyword = quote_plus(search_query)
    url = f'{BASE_API}/v1/api/tim-kiem?keyword={keyword}'

    data = get_json(url)
    if not data:
        yield Listitem()
        return

    items = []
    if isinstance(data, dict):
        if 'data' in data and isinstance(data['data'], dict):
            items = data['data'].get('items', [])
        else:
            items = data.get('items', [])

    if not items:
        item = Listitem()
        item.label = f'Không tìm thấy phim nào cho "{search_query}"'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    slugs = [item.get('slug') for item in items if item.get('slug')]
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(process_url, slugs)
        for s, info in results:
            if info:
                name, poster, content, year = info
                list_item = Listitem()
                list_item.label = f'{name} ({year})' if year else name
                list_item.info['plot'] = content
                list_item.info['mediatype'] = 'tvshow'
                list_item.info['year'] = year
                list_item.art['thumb'] = list_item.art['poster'] = poster
                list_item.set_callback(chi_tiet, s)
                yield list_item


# ============================================================
# CHI TIẾT PHIM (RESUME THEO SERVER)
# ============================================================

@Route.register
def chi_tiet(plugin, slug):
    yield []

    data = get_json(f'{BASE_API}/phim/{slug}')
    if not data:
        yield Listitem()
        return

    movie = data.get('movie', data) if isinstance(data, dict) else {}
    episodes = data.get('episodes', []) if isinstance(data, dict) else []

    name = movie.get('name', '')
    poster = fix_image(movie.get('poster_url') or movie.get('thumb_url'))
    content = unescape(movie.get('content', '') or '')
    content = re.sub(r'<[^>]+>', '', content)
    origin_name = movie.get('origin_name', '')

    if not episodes:
        item = Listitem()
        item.label = 'Phim chưa có tập hoặc chỉ có trailer'
        item.info['plot'] = content
        item.info['mediatype'] = 'episode'
        item.art['thumb'] = item.art['poster'] = poster
        yield item
        return

    for server in episodes:
        server_name = (server.get('server_name', 'Server') or '').strip()
        for ep in server.get('server_data', []):
            ep_name = ep.get('name', '')
            link_m3u8 = ep.get('link_m3u8', '')

            if not link_m3u8:
                continue

            # Lấy vị trí xem dở THEO SERVER
            resume_pos, _ = get_resume_position(slug, ep_name, server_name)

            item = Listitem()
            if resume_pos > 0:
                mins = resume_pos // 60
                secs = resume_pos % 60
                item.label = (
                    f'[{server_name}] Tập {ep_name} '
                    f'[COLOR yellow]>> Xem tiếp {mins}:{secs:02d}[/COLOR]'
                )
            else:
                item.label = f'[{server_name}] Tập {ep_name}'

            item.info['mediatype'] = 'episode'
            item.info['plot'] = content
            item.info['tvshowtitle'] = name
            item.info['originaltitle'] = origin_name
            item.art['thumb'] = item.art['poster'] = poster
            item.set_callback(
                play_kkphim,
                link_m3u8,
                f'{name} - Tập {ep_name}',
                slug,
                ep_name,
                resume_pos,
                server_name,
            )
            yield item


# ============================================================
# RESOLVER - PHÁT VIDEO (RESUME THEO SERVER)
# ============================================================

@Resolver.register
def play_kkphim(plugin, url, title, movie_slug='', episode_name='',
                resume_pos=0, server_name=''):
    """Phát video với tính năng resume theo server."""
    save_watch_history(title, url)

    item = Listitem()
    item.label = title
    item.path = stream(url)

    item.property['inputstream'] = 'inputstream.ffmpegdirect'
    item.property['inputstream.ffmpegdirect.manifest_type'] = 'hls'
    item.property['inputstream.ffmpegdirect.stream_headers'] = (
        f'User-Agent={USER_AGENT}&Referer={BASE_WEB}/'
    )
    item.property['inputstream.ffmpegdirect.manifest_headers'] = (
        item.property['inputstream.ffmpegdirect.stream_headers']
    )

    if movie_slug and episode_name:
        _start_resume_tracker(
            movie_slug, episode_name, resume_pos, server_name
        )

    return item


def _start_resume_tracker(movie_slug, episode_name, start_pos=0, server_name=''):
    """Theo dõi vị trí phát, seek tới start_pos nếu có."""
    import threading
    import time

    def tracker():
        monitor = Monitor()
        player = Player()

        time.sleep(5)

        # === SEEK TỚI VỊ TRÍ RESUME ===
        if start_pos > 0:
            try:
                waited = 0
                while not player.isPlayingVideo() and waited < 15:
                    time.sleep(1)
                    waited += 1

                if player.isPlayingVideo():
                    Script.log(f'[KKPhim] Seek to {start_pos}s')
                    player.seekTime(float(start_pos))
                    time.sleep(2)
                    Script.log(f'[KKPhim] After seek, pos = {player.getTime()}')
            except Exception as e:
                Script.log(f'[KKPhim] Lỗi seek: {e}')

        # === THEO DÕI VÀ LƯU VỊ TRÍ ===
        last_save = 0
        no_video_count = 0

        while not monitor.abortRequested():
            if player.isPlayingVideo():
                no_video_count = 0
                try:
                    pos = player.getTime()
                    total = player.getTotalTime()
                    now = time.time()

                    if now - last_save >= 10:
                        if total > 30 and pos > 0:
                            save_resume_position(
                                movie_slug, episode_name, pos, total, server_name
                            )
                            last_save = now
                except Exception as e:
                    Script.log(f'[KKPhim] Lỗi tracker: {e}')
            else:
                no_video_count += 1
                if no_video_count >= 5:
                    try:
                        pos = player.getTime()
                        total = player.getTotalTime()
                        if total > 30 and pos > 0:
                            save_resume_position(
                                movie_slug, episode_name, pos, total, server_name
                            )
                    except:
                        pass
                    break

            time.sleep(1)

    t = threading.Thread(target=tracker, daemon=True)
    t.start()


# ============================================================
# LỊCH SỬ TÌM KIẾM
# ============================================================

HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20


def save_search_history(keyword):
    if not keyword:
        return
    history = read_json_file(HISTORY_FILE, [])
    if keyword in history:
        history.remove(keyword)
    history.insert(0, keyword)
    history = history[:MAX_HISTORY]
    write_json_file(HISTORY_FILE, history)


def lich_su_tim_kiem_menu():
    history = read_json_file(HISTORY_FILE, [])
    if not history:
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ TÌM KIẾM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_tim_kiem)
    yield item


@Route.register
def lich_su_tim_kiem(plugin):
    history = read_json_file(HISTORY_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử tìm kiếm'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    for keyword in history:
        item = Listitem()
        item.label = keyword
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    write_json_file(HISTORY_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()


# ============================================================
# LỊCH SỬ XEM PHIM
# ============================================================

WATCH_FILE = 'watch_history.json'
MAX_WATCH = 20


def save_watch_history(title, url):
    if not title or not url:
        return
    history = read_json_file(WATCH_FILE, [])
    history = [h for h in history if h.get('title') != title]
    history.insert(0, {'title': title, 'url': url})
    history = history[:MAX_WATCH]
    write_json_file(WATCH_FILE, history)


def lich_su_xem_phim_menu():
    history = read_json_file(WATCH_FILE, [])
    if not history:
        return
    item = Listitem()
    item.label = '[B]LỊCH SỬ XEM PHIM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(lich_su_xem_phim)
    yield item


@Route.register
def lich_su_xem_phim(plugin):
    history = read_json_file(WATCH_FILE, [])

    clear_item = Listitem()
    clear_item.label = '[B]XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_xem_phim)
    yield clear_item

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử xem phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    for entry in history:
        title = entry.get('title', '')
        url = entry.get('url', '')
        if not title or not url:
            continue
        item = Listitem()
        item.label = title
        item.art['thumb'] = TRANSPARENT_ICON
        item.info['mediatype'] = 'episode'
        item.set_callback(play_kkphim, url, title)
        yield item


@Route.register
def xoa_lich_su_xem_phim(plugin):
    write_json_file(WATCH_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()