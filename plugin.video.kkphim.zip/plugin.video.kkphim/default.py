from codequick import Route, Listitem, run
from resources.lib import kkphim
from resources.lib.utils import setup_kodi_cache

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)


@Route.register
def root(plugin):
    """Menu chính của add-on KK Phim."""
    setup_kodi_cache()

    # === TÌM KIẾM ===
    item = Listitem()
    item.label = '[B]TÌM KIẾM[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.tim_kiem_dialog)
    yield item

    # === PHIM MỚI ===
    item = Listitem()
    item.label = '[B]PHIM MỚI CẬP NHẬT[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.danh_sach, 'phim-moi-cap-nhat', 1)
    yield item

    # === PHIM LẺ ===
    item = Listitem()
    item.label = '[B]PHIM LẺ[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.danh_sach, 'phim-le', 1)
    yield item

    # === PHIM BỘ ===
    item = Listitem()
    item.label = '[B]PHIM BỘ[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.danh_sach, 'phim-bo', 1)
    yield item

    # === THỂ LOẠI ===
    item = Listitem()
    item.label = '[B]THỂ LOẠI[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.the_loai)
    yield item

    # === QUỐC GIA ===
    item = Listitem()
    item.label = '[B]QUỐC GIA[/B]'
    item.art['thumb'] = TRANSPARENT_ICON
    item.set_callback(kkphim.quoc_gia)
    yield item

    # === LỊCH SỬ ===
    yield from kkphim.lich_su_tim_kiem_menu()
    yield from kkphim.lich_su_xem_phim_menu()


if __name__ == '__main__':
    run()