from codequick import Route, Listitem, Resolver, Script
from resources.lib.utils import (
    get_json, stream, fix_image,
    read_json_file, write_json_file,
    BASE_API, BASE_WEB, USER_AGENT,
)
from concurrent.futures import ThreadPoolExecutor
from html import unescape
from xbmc import executebuiltin


# ============================================================
# HÀM LẤY THÔNG TIN TÓM TẮT PHIM
# ============================================================

def get_movie_info(slug):
    """Lấy thông tin tóm tắt của một phim từ slug."""
    data = get_json(f'{BASE_API}/phim/{slug}')
    if not data:
        return None
    try:
        # API trả về dict có key 'movie'
        movie = data.get('movie', data)
        name = movie.get('name', 'Không có tên')
        poster = fix_image(
            movie.get('poster_url') or movie.get('thumb_url')
        )
        content = unescape(movie.get('content', '') or '')
        year = movie.get('year', '')
        return (name, poster, content, year)
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi parse info {slug}: {e}')
        return None


def process_url(slug):
    """Wrapper cho ThreadPoolExecutor."""
    return slug, get_movie_info(slug)


# ============================================================
# DANH SÁCH PHIM (có phân trang)
# ============================================================

@Route.register
def danh_sach(plugin, slug='phim-moi-cap-nhat', page=1):
    """Hiển thị danh sách phim theo bộ lọc."""

    # Xác định URL API
    if slug == 'phim-moi-cap-nhat':
        url = f'{BASE_API}/danh-sach/phim-moi-cap-nhat-v2'
    else:
        url = f'{BASE_API}/v1/api/danh-sach/{slug}'

    data = get_json(url, {'page': page, 'limit': 30})
    if not data:
        yield Listitem()
        return

    # Lấy items (xử lý 2 cấu trúc: data.items hoặc data.data.items)
    items = []
    if isinstance(data, dict):
        if 'data' in data and isinstance(data['data'], dict):
            items = data['data'].get('items', [])
        else:
            items = data.get('items', [])

    if not items:
        item = Listitem()
        item.label = '⚠️ Không có phim'
        yield item
        return

    # Đa luồng lấy thông tin chi tiết
    slugs = [item.get('slug') for item in items if item.get('slug')]
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(process_url, slugs)
        for s, info in results:
            if info:
                name, poster, content, year = info
                list_item = Listitem()
                list_item.label = f'{name} ({year})' if year else name
                list_item.info['plot'] = content or f'Phim: {name}'
                list_item.info['mediatype'] = 'tvshow'
                list_item.info['year'] = year
                list_item.art['thumb'] = list_item.art['poster'] = poster
                list_item.set_callback(chi_tiet, s)
                yield list_item

    # Phân trang
    if len(items) >= 30:
        next_item = Listitem()
        next_item.label = f'➡️ Trang {page + 1}'
        next_item.info['mediatype'] = 'tvshow'
        next_item.art['thumb'] = next_item.art['poster'] = (
            'https://raw.githubusercontent.com/kenvnm/kvn/main/next.png'
        )
        next_item.set_callback(danh_sach, slug, page + 1)
        yield next_item


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem(plugin, search_query):
    """Tìm kiếm phim theo từ khóa."""
    if not search_query:
        return

    # Lưu lịch sử tìm kiếm
    save_search_history(search_query)

    # URL tìm kiếm
    from urllib.parse import quote_plus
    keyword = quote_plus(search_query)
    url = f'{BASE_API}/v1/api/tim-kiem?keyword={keyword}'

    data = get_json(url)
    if not data:
        yield Listitem()
        return

    # Lấy items
    items = []
    if isinstance(data, dict):
        if 'data' in data and isinstance(data['data'], dict):
            items = data['data'].get('items', [])
        else:
            items = data.get('items', [])

    if not items:
        item = Listitem()
        item.label = f'⚠️ Không tìm thấy phim nào cho "{search_query}"'
        yield item
        return

    # Đa luồng
    slugs = [item.get('slug') for item in items if item.get('slug')]
    with ThreadPoolExecutor(max_workers=5) as ex:
        results = ex.map(process_url, slugs)
        for s, info in results:
            if info:
                name, poster, content, year = info
                list_item = Listitem()
                list_item.label = f'{name} ({year})' if year else name
                list_item.info['plot'] = content
                list_item.info['mediatype'] = 'tvshow'
                list_item.info['year'] = year
                list_item.art['thumb'] = list_item.art['poster'] = poster
                list_item.set_callback(chi_tiet, s)
                yield list_item


# ============================================================
# CHI TIẾT PHIM
# ============================================================

@Route.register
def chi_tiet(plugin, slug):
    """Hiển thị chi tiết phim và danh sách tập."""
    yield []  # Xóa cache container

    data = get_json(f'{BASE_API}/phim/{slug}')
    if not data:
        yield Listitem()
        return

    # Lấy movie và episodes
    movie = data.get('movie', data) if isinstance(data, dict) else {}
    episodes = data.get('episodes', []) if isinstance(data, dict) else []

    name = movie.get('name', '')
    poster = fix_image(
        movie.get('poster_url') or movie.get('thumb_url')
    )
    content = unescape(movie.get('content', '') or '')
    origin_name = movie.get('origin_name', '')

    # Nếu không có tập
    if not episodes:
        item = Listitem()
        item.label = '⚠️ Phim chưa có tập hoặc chỉ có trailer'
        item.info['plot'] = content
        item.info['mediatype'] = 'episode'
        item.art['thumb'] = item.art['poster'] = poster
        yield item
        return

    # Duyệt qua các server và tập
    for server in episodes:
        server_name = (server.get('server_name', 'Server') or '').strip()
        for ep in server.get('server_data', []):
            ep_name = ep.get('name', '')
            link_m3u8 = ep.get('link_m3u8', '')

            if not link_m3u8:
                continue

            item = Listitem()
            item.label = f'[{server_name}] Tập {ep_name}'
            item.info['mediatype'] = 'episode'
            item.info['plot'] = content
            item.info['tvshowtitle'] = name
            item.info['originaltitle'] = origin_name
            item.art['thumb'] = item.art['poster'] = poster
            item.set_callback(
                play_kkphim,
                link_m3u8,
                f'{name} - Tập {ep_name}'
            )
            yield item


# ============================================================
# RESOLVER - PHÁT VIDEO
# ============================================================

@Resolver.register
def play_kkphim(plugin, url, title):
    """Phát video từ link m3u8 của KKPhim."""
    # Lưu lịch sử xem
    save_watch_history(title, url)

    item = Listitem()
    item.label = title
    item.path = stream(url)

    # Cấu hình inputstream.adaptive cho HLS
    item.property['inputstream'] = 'inputstream.adaptive'
    item.property['inputstream.adaptive.manifest_type'] = 'hls'
    item.property['inputstream.adaptive.stream_headers'] = (
        f'User-Agent={USER_AGENT}&Referer={BASE_WEB}/'
    )
    item.property['inputstream.adaptive.manifest_headers'] = (
        item.property['inputstream.adaptive.stream_headers']
    )

    return item


# ============================================================
# LỊCH SỬ TÌM KIẾM
# ============================================================

HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20


def save_search_history(keyword):
    """Lưu từ khóa vào lịch sử."""
    if not keyword:
        return
    history = read_json_file(HISTORY_FILE, [])
    if keyword in history:
        history.remove(keyword)
    history.insert(0, keyword)
    history = history[:MAX_HISTORY]
    write_json_file(HISTORY_FILE, history)


def lich_su_tim_kiem_menu():
    """Hiển thị menu lịch sử tìm kiếm (nếu có)."""
    history = read_json_file(HISTORY_FILE, [])
    if not history:
        return
    item = Listitem()
    item.label = '🕘 Lịch Sử Tìm Kiếm'
    item.info['mediatype'] = 'tvshow'
    item.set_callback(lich_su_tim_kiem)
    yield item


@Route.register
def lich_su_tim_kiem(plugin):
    """Hiển thị danh sách từ khóa đã tìm."""
    history = read_json_file(HISTORY_FILE, [])

    # Nút xóa toàn bộ
    clear_item = Listitem()
    clear_item.label = '🗑️ Xóa toàn bộ lịch sử'
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử tìm kiếm'
        yield item
        return

    for keyword in history:
        item = Listitem()
        item.label = f'🔍 {keyword}'
        item.info['mediatype'] = 'tvshow'
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    """Xóa toàn bộ lịch sử tìm kiếm."""
    write_json_file(HISTORY_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()


# ============================================================
# LỊCH SỬ XEM PHIM
# ============================================================

WATCH_FILE = 'watch_history.json'
MAX_WATCH = 20


def save_watch_history(title, url):
    """Lưu phim đã xem."""
    if not title or not url:
        return
    history = read_json_file(WATCH_FILE, [])
    history = [h for h in history if h.get('title') != title]
    history.insert(0, {'title': title, 'url': url})
    history = history[:MAX_WATCH]
    write_json_file(WATCH_FILE, history)


def lich_su_xem_phim_menu():
    """Hiển thị menu lịch sử xem phim (nếu có)."""
    history = read_json_file(WATCH_FILE, [])
    if not history:
        return
    item = Listitem()
    item.label = '📺 Lịch Sử Xem Phim'
    item.info['mediatype'] = 'tvshow'
    item.set_callback(lich_su_xem_phim)
    yield item


@Route.register
def lich_su_xem_phim(plugin):
    """Hiển thị danh sách phim đã xem."""
    history = read_json_file(WATCH_FILE, [])

    # Nút xóa
    clear_item = Listitem()
    clear_item.label = '🗑️ Xóa toàn bộ lịch sử'
    clear_item.set_callback(xoa_lich_su_xem_phim)
    yield clear_item

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử xem phim'
        yield item
        return

    for entry in history:
        title = entry.get('title', '')
        url = entry.get('url', '')
        if not title or not url:
            continue
        item = Listitem()
        item.label = f'▶️ {title}'
        item.info['mediatype'] = 'episode'
        item.set_callback(play_kkphim, url, title)
        yield item


@Route.register
def xoa_lich_su_xem_phim(plugin):
    """Xóa toàn bộ lịch sử xem phim."""
    write_json_file(WATCH_FILE, [])
    executebuiltin('Container.Refresh()')
    yield Listitem()