import os
import json
import requests
from codequick import Script
from xbmcvfs import translatePath

# ============================================================
# CẤU HÌNH
# ============================================================

USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
BASE_API = 'https://phimapi.com'
BASE_WEB = 'https://kkphim.com'
ADDON_DATA = os.path.join(
    translatePath('special://userdata/addon_data'),
    'plugin.video.kkphim'
)


# ============================================================
# HTTP
# ============================================================

def get_json(url, params=None, timeout=30):
    """Gọi API và trả về JSON. Trả về None nếu lỗi."""
    headers = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}
    try:
        r = requests.get(url, headers=headers, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi gọi API {url}: {e}')
        return None


# ============================================================
# STREAM
# ============================================================

def stream(url):
    """Thêm User-Agent vào link stream."""
    if not url:
        return url
    return f'{url}|User-Agent={USER_AGENT}'


def fix_image(url):
    """Xử lý URL ảnh (tránh lỗi khi ảnh là dict rỗng)."""
    if isinstance(url, str) and url.startswith('http'):
        return url
    return 'https://raw.githubusercontent.com/kenvnm/kvn/main/kkphim.png'


# ============================================================
# LƯU TRỮ FILE (Lịch sử)
# ============================================================

def _ensure_dir():
    if not os.path.exists(ADDON_DATA):
        os.makedirs(ADDON_DATA)


def _file_path(name):
    _ensure_dir()
    return os.path.join(ADDON_DATA, name)


def read_json_file(name, default=None):
    """Đọc file JSON, trả về giá trị mặc định nếu lỗi."""
    path = _file_path(name)
    if not os.path.exists(path):
        return default if default is not None else []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi đọc file {name}: {e}')
        return default if default is not None else []


def write_json_file(name, data):
    """Ghi dữ liệu vào file JSON."""
    path = _file_path(name)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        Script.log(f'[KKPhim] Lỗi ghi file {name}: {e}')
        return False