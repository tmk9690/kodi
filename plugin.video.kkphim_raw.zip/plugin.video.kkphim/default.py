from codequick import Route, Listitem, run
from resources.lib import kkphim


@Route.register
def root(plugin):
    """Menu chính của add-on KK Phim."""

    # === TÌM KIẾM ===
    yield Listitem.search(kkphim.tim_kiem)

    # === PHIM MỚI ===
    item = Listitem()
    item.label = '🆕 Phim Mới Cập Nhật'
    item.info['mediatype'] = 'tvshow'
    item.set_callback(kkphim.danh_sach, 'phim-moi-cap-nhat', 1)
    yield item

    # === PHIM LẺ ===
    item = Listitem()
    item.label = '🎬 Phim Lẻ'
    item.info['mediatype'] = 'tvshow'
    item.set_callback(kkphim.danh_sach, 'phim-le', 1)
    yield item

    # === PHIM BỘ ===
    item = Listitem()
    item.label = '📺 Phim Bộ'
    item.info['mediatype'] = 'tvshow'
    item.set_callback(kkphim.danh_sach, 'phim-bo', 1)
    yield item

    # === LỊCH SỬ TÌM KIẾM (chỉ hiện nếu có dữ liệu) ===
    yield from kkphim.lich_su_tim_kiem_menu()

    # === LỊCH SỬ XEM PHIM (chỉ hiện nếu có dữ liệu) ===
    yield from kkphim.lich_su_xem_phim_menu()


if __name__ == '__main__':
    run()