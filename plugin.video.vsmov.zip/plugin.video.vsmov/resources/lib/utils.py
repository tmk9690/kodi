import os
import json
import requests
from codequick import Script
from xbmcvfs import translatePath


USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)
BASE_API = 'https://vsmov.com/api'
BASE_WEB = 'https://vsmov.com'
ADDON_DATA = os.path.join(
    translatePath('special://userdata/addon_data'),
    'plugin.video.vsmov'
)


# ============================================================
# HTTP
# ============================================================

def get_json(url, params=None, timeout=30, referer=None, origin=None):
    """Gọi API và trả về JSON."""
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    try:
        r = requests.get(url, headers=headers, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi gọi API {url}: {e}')
        return None


def get_html(url, referer=None, origin=None, timeout=30):
    """Fetch HTML với header đầy đủ."""
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    try:
        r = requests.get(url, headers=headers, timeout=timeout)
        r.encoding = 'utf-8'
        return r.text
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi fetch HTML {url}: {e}')
        return None


# ============================================================
# HELPERS
# ============================================================

def fix_image(url):
    """Xử lý URL ảnh (poster_url có thể là {} rỗng)."""
    if isinstance(url, str) and url.startswith('http'):
        return url
    return 'https://raw.githubusercontent.com/kenvnm/kvn/main/kkphim.png'


def stream(url, referer='', origin=''):
    """Thêm header vào URL stream cho inputstream."""
    if not url:
        return url
    h = f'User-Agent={USER_AGENT}'
    if referer:
        h += f'&Referer={referer}'
    if origin:
        h += f'&Origin={origin}'
    return f'{url}|{h}'