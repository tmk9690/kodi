import os
import re
import json
from codequick import Route, Listitem, Resolver, Script
from resources.lib.utils import (
    get_json, get_html, fix_image, stream,
    BASE_API, USER_AGENT,
)
from html import unescape
from xbmc import Keyboard, executebuiltin
from xbmcvfs import translatePath

TRANSPARENT_ICON = (
    'https://upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png'
)


# ============================================================
# LỊCH SỬ TÌM KIẾM (FILE STORAGE)
# ============================================================

SEARCH_HISTORY_FILE = 'search_history.json'
MAX_HISTORY = 20


def _addon_data_dir():
    """Thư mục lưu dữ liệu add-on."""
    path = os.path.join(
        translatePath('special://userdata/addon_data'),
        'plugin.video.vsmov'
    )
    if not os.path.exists(path):
        try:
            os.makedirs(path)
        except Exception as e:
            Script.log(f'[VSMOV] Lỗi tạo thư mục: {e}')
    return path


def _search_history_path():
    return os.path.join(_addon_data_dir(), SEARCH_HISTORY_FILE)


def get_search_history():
    """Đọc danh sách từ khóa đã tìm."""
    path = _search_history_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi đọc search history: {e}')
        return []


def save_search_history(keyword):
    """Lưu từ khóa vào lịch sử (mới nhất lên đầu)."""
    if not keyword:
        return
    history = get_search_history()
    if keyword in history:
        history.remove(keyword)
    history.insert(0, keyword)
    history = history[:MAX_HISTORY]
    try:
        with open(_search_history_path(), 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi ghi search history: {e}')


def clear_search_history():
    """Xóa toàn bộ lịch sử tìm kiếm."""
    try:
        with open(_search_history_path(), 'w', encoding='utf-8') as f:
            json.dump([], f)
    except Exception as e:
        Script.log(f'[VSMOV] Lỗi xóa search history: {e}')


# ============================================================
# DIALOG TÌM KIẾM (buộc gõ mới mỗi lần)
# ============================================================

@Route.register
def tim_kiem_dialog(plugin):
    """Mở dialog nhập từ khóa — luôn bắt đầu với text rỗng."""
    keyboard = Keyboard('Tìm kiếm phim')
    # Xóa sạch text cũ + default
    try:
        keyboard.setDefault('')
        keyboard.setText('')
    except Exception:
        pass

    keyboard.doModal()

    if keyboard.isConfirmed():
        q = keyboard.getText().strip()
        if q:
            save_search_history(q)
            yield from tim_kiem(plugin, q)
        else:
            yield Listitem()
    else:
        yield Listitem()


# ============================================================
# LỊCH SỬ TÌM KIẾM (MENU)
# ============================================================

@Route.register
def lich_su_tim_kiem(plugin):
    """Hiển thị danh sách từ khóa đã tìm."""
    history = get_search_history()

    if not history:
        item = Listitem()
        item.label = 'Chưa có lịch sử tìm kiếm'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    # Nút xóa toàn bộ
    clear_item = Listitem()
    clear_item.label = '[B]🗑️ XÓA TOÀN BỘ LỊCH SỬ[/B]'
    clear_item.art['thumb'] = TRANSPARENT_ICON
    clear_item.set_callback(xoa_lich_su_tim_kiem)
    yield clear_item

    # Danh sách từ khóa
    for keyword in history:
        item = Listitem()
        item.label = f'🔍 {keyword}'
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(tim_kiem, keyword)
        yield item


@Route.register
def xoa_lich_su_tim_kiem(plugin):
    """Xóa toàn bộ lịch sử tìm kiếm."""
    clear_search_history()
    executebuiltin('Container.Refresh()')
    yield Listitem()


# ============================================================
# HIỂN THỊ DANH SÁCH PHIM
# ============================================================

def _render_movie_list(items):
    """
    Hiển thị danh sách phim — KHÔNG cần gọi API chi tiết.
    API list đã trả về name, poster_url, thumb_url, year.
    """
    for it in items:
        slug = it.get('slug')
        if not slug:
            continue

        name = it.get('name', '')
        year = it.get('year', '')
        poster = fix_image(it.get('poster_url') or it.get('thumb_url'))
        origin_name = it.get('origin_name', '')

        li = Listitem()
        li.label = f'{name} ({year})' if year else name
        li.info['mediatype'] = 'tvshow'
        li.info['year'] = year
        li.info['originaltitle'] = origin_name
        li.info['plot'] = origin_name
        li.art['thumb'] = li.art['poster'] = poster
        li.set_callback(chi_tiet, slug)
        yield li


# ============================================================
# DANH SÁCH PHIM
# ============================================================

@Route.register
def danh_sach(plugin, slug='phim-moi-cap-nhat', page=1):
    """Response: {status, items: [...], pagination: {}}"""
    url = f'{BASE_API}/danh-sach/{slug}'
    data = get_json(url, {'page': page, 'limit': 15})

    if not data or not isinstance(data, dict):
        item = Listitem()
        item.label = '⚠️ Không tải được dữ liệu'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    items = data.get('items', [])
    if not items:
        item = Listitem()
        item.label = 'Không có phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    yield from _render_movie_list(items)

    pagination = data.get('pagination', {})
    current = pagination.get('currentPage', page)
    total = pagination.get('totalPages', 1)
    if current < total:
        n = Listitem()
        n.label = f'➡️ Trang {current + 1} / {total}'
        n.art['thumb'] = TRANSPARENT_ICON
        n.set_callback(danh_sach, slug, current + 1)
        yield n


# ============================================================
# THỂ LOẠI
# ============================================================

@Route.register
def the_loai(plugin):
    """Response: {status, data: {items: [{name, slug}]}}"""
    data = get_json(f'{BASE_API}/the-loai')
    if not data or not isinstance(data, dict):
        yield Listitem()
        return

    items = data.get('data', {}).get('items', [])
    for it in items:
        name = it.get('name', '')
        slug = it.get('slug', '')
        if not slug:
            continue
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach_the_loai, slug, 1)
        yield item


@Route.register
def danh_sach_the_loai(plugin, slug, page=1):
    """Response: {status, items: [...], pagination: {}}"""
    url = f'{BASE_API}/the-loai/{slug}'
    data = get_json(url, {'page': page, 'limit': 15})

    if not data or not isinstance(data, dict):
        item = Listitem()
        item.label = '⚠️ Không tải được thể loại'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    items = data.get('items', [])
    if not items:
        item = Listitem()
        item.label = 'Không có phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    yield from _render_movie_list(items)

    pagination = data.get('pagination', {})
    current = pagination.get('currentPage', page)
    total = pagination.get('totalPages', 1)
    if current < total:
        n = Listitem()
        n.label = f'➡️ Trang {current + 1} / {total}'
        n.art['thumb'] = TRANSPARENT_ICON
        n.set_callback(danh_sach_the_loai, slug, current + 1)
        yield n


# ============================================================
# QUỐC GIA
# ============================================================

@Route.register
def quoc_gia(plugin):
    """Response: {status, data: {items: [{name, slug}]}}"""
    data = get_json(f'{BASE_API}/quoc-gia')
    if not data or not isinstance(data, dict):
        yield Listitem()
        return

    items = data.get('data', {}).get('items', [])
    for it in items:
        name = it.get('name', '')
        slug = it.get('slug', '')
        if not slug:
            continue
        item = Listitem()
        item.label = name
        item.art['thumb'] = TRANSPARENT_ICON
        item.set_callback(danh_sach_quoc_gia, slug, 1)
        yield item


@Route.register
def danh_sach_quoc_gia(plugin, slug, page=1):
    """Response: {status, items: [...], pagination: {}}"""
    url = f'{BASE_API}/quoc-gia/{slug}'
    data = get_json(url, {'page': page, 'limit': 15})

    if not data or not isinstance(data, dict):
        item = Listitem()
        item.label = '⚠️ Không tải được quốc gia'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    items = data.get('items', [])
    if not items:
        item = Listitem()
        item.label = 'Không có phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    yield from _render_movie_list(items)

    pagination = data.get('pagination', {})
    current = pagination.get('currentPage', page)
    total = pagination.get('totalPages', 1)
    if current < total:
        n = Listitem()
        n.label = f'➡️ Trang {current + 1} / {total}'
        n.art['thumb'] = TRANSPARENT_ICON
        n.set_callback(danh_sach_quoc_gia, slug, current + 1)
        yield n


# ============================================================
# TÌM KIẾM
# ============================================================

@Route.register
def tim_kiem(plugin, search_query):
    """Response: {status, items: [...], pagination: {}}"""
    if not search_query:
        return

    data = get_json(f'{BASE_API}/tim-kiem',
                    {'keyword': search_query, 'limit': 24, 'page': 1})

    if not data or not isinstance(data, dict):
        yield Listitem()
        return

    items = data.get('items', [])
    if not items:
        item = Listitem()
        item.label = f'Không tìm thấy phim cho "{search_query}"'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    yield from _render_movie_list(items)


# ============================================================
# CHI TIẾT PHIM
# ============================================================

@Route.register
def chi_tiet(plugin, slug):
    """
    Response: {status, movie: {}, episodes: [{server_name, server_data: []}]}
    """
    yield []

    data = get_json(f'{BASE_API}/phim/{slug}')
    if not data or not isinstance(data, dict):
        item = Listitem()
        item.label = '⚠️ Không tải được chi tiết phim'
        item.art['thumb'] = TRANSPARENT_ICON
        yield item
        return

    movie = data.get('movie', {})
    episodes = data.get('episodes', [])

    name = movie.get('name', '')
    poster = fix_image(movie.get('poster_url') or movie.get('thumb_url'))
    content = unescape(movie.get('content', '') or '')
    content = re.sub(r'<[^>]+>', '', content)

    if not episodes:
        item = Listitem()
        item.label = '⚠️ Phim chưa có tập'
        item.info['plot'] = content
        item.info['mediatype'] = 'episode'
        item.art['thumb'] = item.art['poster'] = poster
        yield item
        return

    for server in episodes:
        sv_name = (server.get('server_name', 'Server') or '').replace('\r\n', ' ').strip()
        for ep in server.get('server_data', []):
            ep_name = ep.get('name', '')
            link_embed = ep.get('link_embed', '')
            link_m3u8 = ep.get('link_m3u8', '')
            stream_url = link_m3u8 or link_embed
            if not stream_url:
                continue

            item = Listitem()
            item.label = f'[{sv_name}] Tập {ep_name}'
            item.info['mediatype'] = 'episode'
            item.info['plot'] = content
            item.info['tvshowtitle'] = name
            item.art['thumb'] = item.art['poster'] = poster
            item.set_callback(play_vsmov, stream_url, f'{name} - Tập {ep_name}')
            yield item


# ============================================================
# TRÍCH XUẤT PHỤ ĐỀ TỪ EMBED PAGE
# ============================================================

def _extract_subtitles(embed_url, cdn_origin):
    """
    Fetch HTML player VSMOV và trích xuất URL phụ đề .vtt.
    Trả về list [(label, url), ...].
    """
    subs = []
    html = get_html(embed_url, referer=cdn_origin + '/', origin=cdn_origin)
    if not html:
        Script.log('[VSMOV] Không lấy được HTML player')
        return subs

    # Pattern 1: URL đầy đủ: https://.../vie_xxx.vtt
    pattern1 = r'(https?://[^\s"\'<>\\]+\.vtt[^\s"\'<>\\]*)'
    for m in re.findall(pattern1, html):
        url = m.replace('\\/', '/')
        if 'vie_' in url and not any('vie' in s[0].lower() for s in subs):
            subs.append(('Tiếng Việt', url))
        elif 'eng_' in url and not any('eng' in s[0].lower() for s in subs):
            subs.append(('Tiếng Anh', url))

    # Pattern 2: Path tương đối: subtitle/vie_xxx.vtt
    if not subs:
        pattern2 = r'["\']((?:[^"\']*)?subtitle/[^"\']+\.vtt[^"\']*)["\']'
        for m in re.findall(pattern2, html):
            url = m.replace('\\/', '/')
            if url.startswith('/'):
                url = f'{cdn_origin}{url}'
            elif not url.startswith('http'):
                url = f'{cdn_origin}/{url.lstrip("/")}'

            if 'vie_' in url and not any('vie' in s[0].lower() for s in subs):
                subs.append(('Tiếng Việt', url))
            elif 'eng_' in url and not any('eng' in s[0].lower() for s in subs):
                subs.append(('Tiếng Anh', url))

    Script.log(f'[VSMOV] Tìm thấy {len(subs)} phụ đề')
    return subs


# ============================================================
# RESOLVER — PHÁT VIDEO (TỐI ƯU BUFFERING)
# ============================================================

@Resolver.register
def play_vsmov(plugin, url, title):
    """
    Phát video VSMOV với tối ưu buffering.
    """
    from urllib.parse import urlparse

    original_url = url

    # Chuyển link_embed /video/{uuid} → master.m3u8
    if '/video/' in url and '.m3u8' not in url:
        parsed = urlparse(url)
        domain = f'{parsed.scheme}://{parsed.netloc}'
        uuid = url.split('/video/')[-1].split('?')[0].strip('/')
        url = f'{domain}/stream/{uuid}/master.m3u8'
        Script.log(f'[VSMOV] Chuyển đổi URL: {url}')

    parsed = urlparse(url)
    cdn_origin = f'{parsed.scheme}://{parsed.netloc}'

    # Trích xuất phụ đề từ embed page gốc
    subs = []
    if '/video/' in original_url:
        try:
            subs = _extract_subtitles(original_url, cdn_origin)
        except Exception as e:
            Script.log(f'[VSMOV] Lỗi trích xuất phụ đề: {e}')

    item = Listitem()
    item.label = title
    item.path = stream(url, referer=cdn_origin + '/', origin=cdn_origin)

    # Gắn phụ đề vào ListItem
    if subs:
        item.subtitles = [s[1] for s in subs]
        Script.log(f'[VSMOV] Đã gắn {len(subs)} phụ đề')

    # === CẤU HÌNH INPUTSTREAM.ADAPTIVE ===
    item.property['inputstream'] = 'inputstream.adaptive'
    item.property['inputstream.adaptive.stream_headers'] = (
        f'User-Agent={USER_AGENT}&Referer={cdn_origin}/&Origin={cdn_origin}'
    )
    item.property['inputstream.adaptive.manifest_headers'] = (
        item.property['inputstream.adaptive.stream_headers']
    )

    # === TỐI ƯU BUFFERING ===
    item.property['inputstream.adaptive.manifest_config'] = (
        '{"hls": {"ignore_manifest_content_type": true}}'
    )
    item.property['inputstream.adaptive.max_bandwidth'] = '8000000'
    item.property['inputstream.adaptive.chooser_bandwidth_max'] = '8000000'
    item.property['inputstream.adaptive.chooser_resolution_max'] = '1080'

    return item